"""Handlers for DAK Jupyter extension."""

from jupyter_client.kernelspec import KernelSpecManager
from jupyter_server.gateway import managers

from . import utils


class FilteringKernelSpecManager(KernelSpecManager):
  """Custom KernelSpecManager that filters remote kernels to return Pyspark/Python Kernels."""

  def __init__(self, *args, **kwargs):
    self.log.info('FilteringKernelSpecManager Constructed')
    super().__init__(*args, **kwargs)
    # Initialize the remote manager to fetch kernels from the Dataproc Kernel
    # Mixer
    self.remote_manager = managers.GatewayKernelSpecManager(*args, **kwargs)
    self._remote_kernels = set()

  async def get_all_specs(self):
    """Fetches all kernels and returns only those where language is 'python'."""
    specs = await self.remote_manager.get_all_specs()

    filtered_specs, filtered_out_names = utils.filter_kernelspecs(specs)

    self.log.info(
        f'Filtered to {len(filtered_specs)} Python and PySpark kernels.'
    )
    self.log.info(f'Filtered out kernelspecs: {filtered_out_names}')

    return filtered_specs
