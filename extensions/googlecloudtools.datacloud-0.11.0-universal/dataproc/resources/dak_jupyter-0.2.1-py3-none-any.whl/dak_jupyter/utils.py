"""Helper utilities for DAK Juypter library."""

import re
from typing import Any
import urllib.parse

# Regex for detecting potentially encoded OAuth URLs. Includes '.' and '-' and
# handles various characters.
_OAUTH_PATTERN = re.compile(
    (
        r'https?[:%a-zA-Z0-9./-]*'
        r'accounts[:%a-zA-Z0-9./-]*'
        r'google[:%a-zA-Z0-9./%?&=+:_-]*'
        r'com[:%a-zA-Z0-9./%?&=+:_-]*'
        r'oauth2[:%a-zA-Z0-9./%?&=+:_-]*'
        r'auth\S*'
    ),
    re.IGNORECASE,
)


def decode_url(url: str) -> str:
  """Decodes a URL, handling potential double-percent encoding.

  Args:
    url: The URL to decode.

  Returns:
    The decoded URL.
  """
  # Ensure we handle potential double-percent encoding like %%3A and standard
  # double encoding like %253A. Recursively replace %% with %
  d = url
  while '%%' in d:
    d = d.replace('%%', '%')
  for _ in range(3):
    new_d = urllib.parse.unquote(d)
    if new_d == d:
      break
    d = new_d
  return d.strip()


def clean_plain_text_oauth(text: str) -> str:
  """Cleans plain text of encoded OAuth URLs.

  Args:
    text: The text to clean.

  Returns:
    The cleaned text with encoded OAuth URLs replaced by their decoded
    values.
  """
  if 'accounts' not in text or 'oauth2' not in text:
    return text
  matches = _OAUTH_PATTERN.findall(text)
  if matches:
    for match in matches:
      decoded = decode_url(match)
      text = text.replace(match, decoded)
  return text


def filter_kernelspecs(
    specs: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
  """Filters remote kernels to return only PySpark/Python kernels.

  Args:
    specs: A dictionary of kernelspecs.

  Returns:
    A tuple of:
      - Input specs, filtered to only applicable kernels.
      - A list of display names of filtered out kernelspecs.
  """
  filtered_specs = {}
  filtered_out_names = []

  for name, resource in specs.items():
    if resource.get('spec', {}).get('language') == 'python':
      filtered_specs[name] = resource
    else:
      filtered_out_names.append(
          resource.get('spec', {}).get('display_name', name)
      )
  return filtered_specs, filtered_out_names
