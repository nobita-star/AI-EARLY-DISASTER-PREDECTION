"""Message filter for Tornado websocket connections."""

import time
from typing import Any, Callable


class MessageFilter:
  """Helper to monkey-patch Tornado websocket conection.

  We drop SparkMonitor messages if the user setting indicates SparkMonitor is
  disabled. This works around the issue where VS Code stops rendering notebook
  cells with over 500 outputs:
  # pylint: disable=line-too-long
  https://github.com/microsoft/vscode/commit/8a1134657342196149fab95e588f8e2ce6399c8a
  # pylint: enable=line-too-long

  Not installing the SparkMonitor listener locally isn't sufficient, since the
  messages are still sent on the wire and counted against the limit.
  """

  def __init__(self, conn: Any, log: Callable[..., None]) -> None:
    self._conn = conn
    self._log = log
    self._dropped = 0
    self._total_dropped = 0
    self._last_log_time = time.time()
    self._close_logged = False
    self._original_read_message = conn.read_message
    self._original_close = conn.close

  def _log_final_summary(self, trigger: str) -> None:
    if not self._close_logged:
      self._log(
          f'Connection closed ({trigger}). Total messages dropped:'
          f' {self._total_dropped}'
      )
      self._close_logged = True

  async def read_message(self, *args: Any, **kwargs: Any) -> Any:
    """Read a message, dropping it if it's from SparkMonitor."""
    while True:
      msg = await self._original_read_message(*args, **kwargs)

      current_time = time.time()
      elapsed = current_time - self._last_log_time
      if elapsed >= 60:
        if self._dropped > 0:
          self._log(
              f'Dropped {self._dropped} messages in the last'
              f' {int(elapsed)} seconds. Total dropped:'
              f' {self._total_dropped}'
          )
          self._dropped = 0
          self._last_log_time = current_time

      if msg is None:
        self._log_final_summary('read_message None')
        return msg

      if isinstance(msg, str):
        if (
            '"application/vnd.sparkmonitor+json"' in msg
            or '"WARNING:SparkMonitorKernel' in msg
        ):
          self._dropped += 1
          self._total_dropped += 1
          continue
      return msg

  def close(self, *args: Any, **kwargs: Any) -> Any:
    self._log_final_summary('close called')
    return self._original_close(*args, **kwargs)

  def patch(self) -> None:
    self._conn.read_message = self.read_message
    self._conn.close = self.close
