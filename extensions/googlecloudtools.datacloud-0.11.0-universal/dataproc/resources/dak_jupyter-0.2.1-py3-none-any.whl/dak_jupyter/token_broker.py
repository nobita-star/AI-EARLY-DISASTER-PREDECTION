"""Token broker implementation for DAK Jupyter server."""

import asyncio
import hashlib
import tornado.web


class TokenExchangeHandler(tornado.web.RequestHandler):
  """Handler for token exchange endpoint.

  Exchanges a hash of an OAuth token for the Jupyter server token. In general,
  the caller should know which OAuth token the server is using for its
  underlying gateway authentication, and sends the hash of that token to this
  endpoint. The endpoint responds with the Jupyter server token unique to the
  current server process.
  """

  def initialize(self):
    # Eagerly look up settings, raising KeyError if missing (indicating
    # programmer error in configuration).
    self.renewer = self.settings['jupyter_token_renewer']
    self.jupyter_token = self.settings['jupyter_token']

  def check_xsrf_cookie(self):
    # Exempt this endpoint from XSRF checks:
    # 1. It uses an Authorization header rather than cookies.
    # 2. The caller can't have an XSRF header at this point; it only gets set by
    #    the regular Jupyter API path, which requires a Jupyter token, which the
    #    caller doesn't have yet.
    pass

  async def post(self):
    auth_header = self.request.headers.get('Authorization')
    if not auth_header:
      self.set_status(401)
      self.write({'error': 'Missing Authorization header'})
      return

    parts = auth_header.split()
    if len(parts) != 2 or parts[0] != 'Hash':
      self.set_status(401)
      self.write({'error': 'Invalid Authorization header format'})
      return

    client_hash = parts[1]

    try:
      # Assume get_token is blocking.
      loop = asyncio.get_event_loop()
      # Force rereading the token from disk, in case the caller refreshed it
      # recently, to ensure it matches what they will give us.
      token = await loop.run_in_executor(
          None,
          self.renewer.force_new_token,
          'Authorization',
          'Bearer',
      )
      if not token:
        self.set_status(500)
        self.write({'error': 'Failed to get token from renewer'})
        return

      server_hash = hashlib.sha256(token.encode('utf-8')).hexdigest()
    except Exception as e:  # pylint: disable=broad-exception-caught
      self.set_status(500)
      self.write({'error': f'Failed to get token from renewer: {e}'})
      return

    if client_hash.lower() == server_hash:
      self.write({'token': self.jupyter_token})
      return

    self.set_status(403)
    self.write({'error': 'Token hash mismatch'})
