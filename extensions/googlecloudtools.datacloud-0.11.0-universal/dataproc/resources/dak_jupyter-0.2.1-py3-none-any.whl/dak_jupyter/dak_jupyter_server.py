"""Launch a local Jupyter server providing access to Google Spark kernels."""

import argparse
import asyncio
import datetime
import json
import os
import secrets
import socket
import sys
import uuid

import certifi

# This tells the 'ssl' library exactly where to look
# It must run before any of the third-party imports, as tornado apparently sets
# up an SSL context at import time.
certifi_path = certifi.where()
os.environ['REQUESTS_CA_BUNDLE'] = certifi_path
os.environ['SSL_CERT_FILE'] = certifi_path

# pylint: disable=g-import-not-at-top
from google.cloud.jupyter_config.tokenrenewer import CommandTokenRenewer
from jupyter_core import paths as jupyter_paths
from jupyter_server import serverapp
import jupyter_server.gateway.connections
import jupyter_server.gateway.gateway_client
import jupyter_server.gateway.managers
import tornado.gen as tornado_gen
import tornado.web as tornado_web
import tornado.websocket as tornado_websocket
from traitlets import config as traitlets_config
from traitlets import default
from traitlets import Unicode

from . import handlers
from . import message_filter
from . import token_broker
from . import utils

# pylint: enable=g-import-not-at-top


# Monkey patch GatewayClient/gateway_request to intercept HTTP errors (like 403)
# and clean up double-encoded URLs in the error messages.
_original_gateway_request = (
    jupyter_server.gateway.gateway_client.gateway_request
)


async def _patched_gateway_request(endpoint, **kwargs):
  """Monkey-patched gateway_request method."""
  try:
    return await _original_gateway_request(endpoint, **kwargs)
  except Exception as e:
    try:
      # Intercept HTTP errors (like 403) and clean up double-encoded URLs in the
      # error messages.
      if isinstance(e, tornado_web.HTTPError):
        # log_message is read-only. We recreate the exception with a cleaned
        # message
        cleaned_log = utils.clean_plain_text_oauth(e.log_message or '')
        cleaned_reason = utils.clean_plain_text_oauth(e.reason or '')
        if cleaned_log != e.log_message or cleaned_reason != e.reason:
          new_e = tornado_web.HTTPError(
              e.status_code,
              cleaned_log,
              *e.args,
              reason=cleaned_reason,
          )
          # Copy over the response if it exists
          if hasattr(e, 'response'):
            new_e.response = e.response
          raise new_e from e
    except (tornado_web.HTTPError, StopIteration):
      raise
    except Exception:  # pylint: disable=broad-exception-caught
      pass
    raise e


# Patch it in the original module and where it is commonly imported.
jupyter_server.gateway.gateway_client.gateway_request = _patched_gateway_request
jupyter_server.gateway.managers.gateway_request = _patched_gateway_request


class _InterceptedTornadoWebsocket:
  """Object to return from monkey-patched tornado.websocket.websocket_connect.

  We monkey-patch the tornado method used to create outbound websocket
  connections to the remote kernels so that it verifies the kernel can
  communicate over those connections.

  We've seen sporadic issues where the outbound websocket connection appears to
  be 'stuck'; messages make it back to the kernel's ZMQ channel but no responses
  from the kernel get sent back on the ZMQ channel.

  When we've seen that, killing and recreating the connection seems to mitigate
  the problem.

  To automate this, we verify that the outbound connection isn't 'stuck' before
  we return it. In case it is stuck, we raise an error so that the connection
  gets retried by the caller.

  The only place in the Jupyter server codebase that calls the method
  'tornado.websocket.websocket_connect' is in the GatewayWebSocketConnection
  class. That means we can monkey patch the method by modifying the value
  imported in that class.

  It also means that all such outbound connections are only being made to kernel
  messaging channels. As such, it is safe to assume that all connections created
  using our patched method will only be for communicating with the remote
  kernels, and we can inject kernel_info_request messages to probe the health of
  those connections without risk of breaking anything.

  Since we are intercepting initial communications with the kernel, any messages
  sent by the kernel before we get back our 'kernel_info_reply' message will get
  dropped.

  That should be OK because the only such message we actually expect the kernel
  to send is an initial 'status' message with an 'execution_state' of
  'starting'. Such a message is only sent once at process startup time, so
  clients aren't guaranteed to receive it anyway (they would have to connect)
  before the one time the message is sent.
  """

  def __init__(self, check_connection_health, sparkmonitor_config_path):
    self.check_connection_health = check_connection_health
    self.sparkmonitor_config_path = sparkmonitor_config_path

  def log(self, *args, **kwargs):
    print('[_InterceptedTornadoWebsocket]', *args, file=sys.stderr, **kwargs)

  async def _read_sparkmonitor_config(self):
    try:
      with open(self.sparkmonitor_config_path, 'r') as f:
        config = json.load(f)
        return config.get('inCellMonitoringEnabled', False)
    except Exception as e:  # pylint: disable=broad-exception-caught
      self.log(
          f'Could not read SparkMonitor config file: {e}. Defaulting to'
          ' filtering enabled (inCellMonitoring is False).'
      )
      return False

  # pylint: disable=invalid-name
  WebSocketClientConnection = tornado_websocket.WebSocketClientConnection
  WebSocketClosedError = tornado_websocket.WebSocketClosedError
  # pylint: enable=invalid-name

  async def _websocket_connect(self, *args, **kwargs):
    """Connect websocket and wait for kernel info response."""
    self.log('Creating the outbound kernel websocket connection...')
    conn = await tornado_websocket.websocket_connect(*args, **kwargs)

    in_cell_monitoring_enabled = await self._read_sparkmonitor_config()

    if in_cell_monitoring_enabled:
      self.log('In-cell monitoring is enabled, skipping message filtering')
    else:
      self.log('In-cell monitoring is disabled, enabling message filtering')
      message_filter.MessageFilter(conn, self.log).patch()

    if not self.check_connection_health:
      return conn

    self.log('Verifying that the created connection is responsive...')
    session_id = uuid.uuid4().hex
    message_id = uuid.uuid4().hex
    conn.write_message(
        json.dumps({
            'channel': 'shell',
            'header': {
                'date': datetime.datetime.now().isoformat(),
                'session': session_id,
                'msg_id': message_id,
                'msg_type': 'kernel_info_request',
                'username': '',
                'version': '5.2',
            },
            'parent_header': {},
            'metadata': {},
            'content': {},
            'buffers': [],
        })
    )
    self.log('Kernel info request sent, waiting for the reply...')
    for _ in range(30):
      try:
        msg = await tornado_gen.with_timeout(
            datetime.timedelta(seconds=1), conn.read_message()
        )
      except (TimeoutError, asyncio.TimeoutError):
        self.log(
            'Timeout waiting for a response message from the backend'
            ' websocket connection'
        )
        continue
      if not msg:
        self.log('Kernel connection closed on the backend')
        raise RuntimeError('Kernel connection closed on the backend')
      resp = json.loads(msg)
      response_type = resp.get('header', {}).get('msg_type', None)
      if response_type == 'kernel_info_reply':
        self.log('Kernel info reply received... returning connection')
        return conn
      self.log(f'Received unrelated response from the kernel: {resp}')
    self.log('Kernel connection did not respond to info requests')
    raise RuntimeError('Kernel connection did not respond to info requests')

  def websocket_connect(self, *args, **kwargs):
    self.log(
        'Returning a future to create the outbound kernel websocket'
        ' connection...'
    )
    return asyncio.ensure_future(self._websocket_connect(*args, **kwargs))


class DataCloudServerApp(serverapp.ServerApp):
  """Custom Jupyter ServerApp for DataCloud."""

  use_token_broker = False

  info_file = Unicode()

  @default('info_file')
  def _default_info_file(self) -> str:
    if self.use_token_broker:
      return os.path.join(self.runtime_dir, f'tbserver-{os.getpid()}.json')
    return os.path.join(self.runtime_dir, f'jpserver-{os.getpid()}.json')

  def init_webapp(self):
    super().init_webapp()
    self.web_app.settings['gateway_url'] = self.gateway_config.url

    renewer = self.gateway_config.gateway_token_renewer
    if not renewer:
      raise ValueError('Gateway token renewer not configured')
    self.web_app.settings['jupyter_token_renewer'] = renewer

    self.web_app.settings['jupyter_token'] = self.identity_provider.token
    if self.use_token_broker:
      self.web_app.add_handlers(
          r'^127\.0\.0\.1(:[0-9]+)?$',
          [(
              f'{self.base_url}exchange_token',
              token_broker.TokenExchangeHandler,
          )],
      )

  def write_server_info_file(self):
    try:
      data = {
          'pid': os.getpid(),
          'port': self.port,
      }
      if self.use_token_broker:
        data['authType'] = 'tokenBroker'
      else:
        data['token'] = getattr(self.identity_provider, 'token', '')

      with jupyter_paths.secure_write(self.info_file) as f:
        json.dump(
            data,
            f,
            indent=2,
            sort_keys=True,
        )
    except Exception as e:  # pylint: disable=broad-exception-caught
      self.log.error(f'Failed to write server-info to {self.info_file}: {e}')

  def write_browser_open_file(self):
    # Browser open file would contain the Jupyter token, skip writing it
    # entirely.
    pass


def main():
  parser = argparse.ArgumentParser(description='Launch local Jupyter server.')
  parser.add_argument(
      '--project-number', required=True, help='Google Cloud Project Number'
  )
  parser.add_argument('--region', required=True, help='Google Cloud Region')
  parser.add_argument(
      '--ide-user-agent', required=True, help='IDE User Agent String'
  )
  parser.add_argument(
      '--is-cloud-shell', action='store_true', help='Running in Cloud Shell'
  )
  parser.add_argument(
      '--adc-auth-bypass', action='store_true', help='Bypass ADC Auth'
  )
  parser.add_argument('--credentials-file', help='Path to credentials file')
  parser.add_argument(
      '--spark-monitor-config',
      required=True,
      help='Path to SparkMonitor config',
  )
  parser.add_argument(
      '--use-token-broker',
      action='store_true',
      help='Enable token broker auth mode',
  )
  parser.add_argument(
      '--check-connection-health',
      action='store_true',
      default=False,
      help=(
          'Check that websocket connections are healthy before trying to use '
          'them.\n'
          '\n'
          'This can have the consequence of causing messages to get dropped '
          'during reconnections.'),
  )

  args = parser.parse_args()
  DataCloudServerApp.use_token_broker = args.use_token_broker
  if args.use_token_broker:
    print('Token broker is enabled', file=sys.stderr)

  print(
      'Injecting the tornado websocket connection interceptor',
      file=sys.stderr,
  )
  jupyter_server.gateway.connections.tornado_websocket = (
      _InterceptedTornadoWebsocket(
          args.check_connection_health, args.spark_monitor_config))

  c = traitlets_config.Config()
  c.ServerApp.kernel_spec_manager_class = handlers.FilteringKernelSpecManager
  c.ServerApp.log_level = 'DEBUG'

  if args.is_cloud_shell:
    c.CommandTokenRenewer.token_command = 'gcloud auth print-access-token'
  elif args.adc_auth_bypass:
    c.CommandTokenRenewer.token_command = (
        'gcloud auth application-default print-access-token'
    )
  else:
    if not args.credentials_file:
      raise ValueError('credentials-file is required when not in Cloud Shell')
    normalized_credentials_path = args.credentials_file.replace('\\', '/')
    inline_script = '; '.join([
        'import json',
        (
            'token = '
            f"json.load(open(r'''{normalized_credentials_path}'''))"
            "['accessToken']"
        ),
        'print(token)',
    ])
    c.CommandTokenRenewer.token_command = (
        f'"{sys.executable}" -c "{inline_script}"'
    )

  gateway_client_headers = json.dumps({
      'Cookie': '_xsrf=XSRF',
      'X-XSRFToken': 'XSRF',
      'User-Agent': args.ide_user_agent,
  })

  c.GatewayClient.url = (
      f'https://{args.project_number}-dot-{args.region}'
      '.kernels.googleusercontent.com'
  )
  c.GatewayClient.gateway_token_renewer_class = CommandTokenRenewer
  c.GatewayClient.auth_token = 'Initial, invalid value'
  c.GatewayClient.auth_scheme = 'Bearer'
  c.GatewayClient.headers = gateway_client_headers
  c.GatewayClient.gateway_retry_max = 45
  c.GatewayClient.gateway_retry_interval = 20
  c.GatewayClient.connect_timeout = 300
  c.GatewayClient.request_timeout = 300

  jupyter_secure_token = secrets.token_hex(32)
  c.IdentityProvider.token = jupyter_secure_token

  # Find free port natively in Python and configure ServerApp to use it.
  with socket.socket() as s:
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
  c.ServerApp.open_browser = False
  c.ServerApp.port = port
  c.ServerApp.ip = '127.0.0.1'

  # Launch the server directly.
  sys.exit(DataCloudServerApp.launch_instance(argv=[], config=c))


if __name__ == '__main__':
  main()
